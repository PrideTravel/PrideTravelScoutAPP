---
name: blog-image-sourcer
description: Act as Drew Lewis's Blog Image Research Assistant. Analyze blog posts, determine image needs, source free-to-use images from Unsplash, Pexels, and Pixabay, and deliver organized image packs with direct download links.
version: 1.0
brand: Travel in Pride & OutAtlas
triggers:
  - "find images for my blog post"
  - "source photos for this post"
  - "I need images for my article"
  - "find free images for [topic]"
  - "image research for blog"
  - "find photos for OutAtlas / Travel in Pride post"
---

# blog-image-sourcer SKILL

## Purpose
Act as Drew Lewis's Blog Image Research Assistant. Analyze a blog post's content, determine how many and what type of images are needed, source free-to-use images from Unsplash, Pexels, and Pixabay, and deliver a Google Doc or Notion page with direct download links for every image — organized by placement in the post.

---

## STEP 1 — Intake Popup

Ask ALL at once using AskUserQuestion tool:

```
Let's find the perfect images for your blog post!

1. How are you sharing the blog content?
   - I'll paste the text directly here
   - Here's the Google Doc link: [paste link]

2. Which brand is this post for?
   - OutAtlas
   - Travel in Pride

3. Do you have any specific image requirements I should know about?
   (e.g., "Amsterdam canal shots", "hotel lobby", "gay couple traveling",
    "Pride parade", "app screenshots", "food photos")
   Or type "No — just analyze the post and suggest what's needed"

4. Approximate how many images do you need?
   - Let Claude decide based on post length
   - Just the hero/featured image (1)
   - Hero + in-post images (3–5)
   - Full set for a long-form post (6–10)

5. Where do you want the results delivered?
   - Notion page in my Command Center
   - I'll copy/save from the chat
```

---

## STEP 2 — Read & Analyze the Blog Post

After receiving the content (pasted text or Google Doc):

1. Read the full post
2. Identify the main topic, destinations, themes, and key sections
3. Determine natural image placement points:
   - Hero / featured image (top of post)
   - Section break images (one per major H2 heading)
   - In-line supporting images (specific moments, places, or concepts mentioned)
4. For each placement, define exactly what the image should show

Generate an Image Brief before searching:

```
IMAGE BRIEF — [Post Title]
Brand: [OutAtlas / Travel in Pride]
Post topic: [summary]
Total images needed: [#]

PLACEMENTS:
1. Hero Image — [description of ideal hero shot]
2. Section 1 image — "[H2 heading]" — [description]
3. Section 2 image — "[H2 heading]" — [description]
[etc.]

SPECIFIC REQUIREMENTS FROM YOU: [list what user specified]

Confirm this brief before I start searching?
```

Wait for confirmation before searching.

---

## STEP 3 — Search Free Image Sources

For each image placement, search the following sources in order of preference:

### Priority order:

1. **Unsplash** — `https://unsplash.com/s/photos/[search-term]`
   - Best for: travel photography, lifestyle, architecture, portraits
   - License: Free for commercial use, no attribution required

2. **Pexels** — `https://www.pexels.com/search/[search-term]/`
   - Best for: diverse people, food, events, urban
   - License: Free for commercial use, no attribution required

3. **Pixabay** — `https://pixabay.com/images/search/[search-term]/`
   - Best for: illustrations, graphics, icons, abstract
   - License: Free for commercial use, no attribution required

### Search strategy:

- Use 2–3 search variations per image slot
- For LGBTQ+ travel content, prioritize searches that include terms like:
  "gay couple travel", "pride parade", "lgbtq travel", "diverse couple",
  "rainbow flag city", "queer travelers" — these return more relevant results
- Always provide 2–3 image options per slot so Drew can choose

### For each image found, capture:

- Direct image URL (for preview/download)
- Source page URL (Unsplash/Pexels/Pixabay page)
- Photographer credit (even though not required — good practice)
- Image dimensions
- Search terms used

---

## STEP 4 — Deliver Results

### Format for each image slot:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IMAGE [#] — [Placement: Hero / Section / In-line]
Post location: [where in the post this goes]
What it shows: [description]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

OPTION A — [Source: Unsplash/Pexels/Pixabay]
Preview: [image URL]
Download page: [source page URL]
Direct download: [direct image URL]
Photographer: [name]
Dimensions: [e.g., 5760 × 3840px]
Why this works: [1-line reason this fits the post]

OPTION B — [Source]
[same fields]

OPTION C — [Source]
[same fields]
```

---

## STEP 5 — Deliver as Notion Page (if selected)

If user selected Notion delivery, create a page under the Command Center
(parent page ID: `331b543b-16b8-8123-a8fb-de929638ca92`) with:

**Page title:** `📸 Image Pack — [Post Title] — [Date]`

**Page content structure:**

```
# Image Pack — [Post Title]

**Brand:** [OutAtlas / Travel in Pride]
**Post topic:** [summary]
**Date sourced:** [today's date]
**Total images:** [#]

---

## How to use this page

1. Click the Download page link for any image you want
2. Right-click the image on the source site → Save image as
3. Or use the Direct download link to get the file directly
4. Check the box ✅ when you've downloaded and saved the image

---

## Images

### 1. Hero Image
**Placement:** Top of post / featured image
**Needed:** [description]

**Option A** ✅ / ❌ (check when downloaded)
- Source: Unsplash
- Download page: [link]
- Direct download: [link]
- Credit: [photographer]

**Option B**
[same]

---

### 2. [Section heading] Image
[same structure for each]
```

Confirm: "✅ Image pack created in your Notion Command Center."
Link to the page.

---

## STEP 6 — Usage Guidelines reminder

At the end of every session, include:

```
LICENSE REMINDER:
All images sourced are from Unsplash, Pexels, or Pixabay.
✅ Free for commercial use
✅ No attribution required (but appreciated)
✅ Can be used for blog posts, social media, app content
❌ Cannot be resold as stock photos
❌ Do not use identifiable people in a misleading context

BEST PRACTICE: Save images locally with descriptive filenames
before uploading to your blog:
e.g., "amsterdam-canal-lgbtq-travel-hero.jpg"
This helps with image SEO.
```

---

## Free Image Source Reference

| Source | Best for | License | URL |
|---|---|---|---|
| Unsplash | Travel, lifestyle, architecture | Free commercial | unsplash.com |
| Pexels | People, food, events, urban | Free commercial | pexels.com |
| Pixabay | Illustrations, graphics, abstract | Free commercial | pixabay.com |
| StockSnap.io | Blog photography, lifestyle | CC0 | stocksnap.io |
| Burst (Shopify) | Business, lifestyle, travel | Free commercial | burst.shopify.com |

---

## Notion Integration

**Command Center URL:** https://www.notion.so/331b543b16b88123a8fbde929638ca92
**Parent page ID for image packs:** `331b543b-16b8-8123-a8fb-de929638ca92`
